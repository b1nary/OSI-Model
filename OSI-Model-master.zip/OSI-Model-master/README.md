# OSI-Model.com

This repo contains the [osi-model.com](https://osi-model.com/) website based on [nanoc](http://nanoc.ws/).

Feel free to fork / reuse / translate :)
