include Nanoc::Helpers::Rendering
